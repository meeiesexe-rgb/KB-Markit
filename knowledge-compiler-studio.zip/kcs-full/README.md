# Knowledge Compiler Studio — Apriso MES Edition
**Enterprise Precision Violet · Trane Technologies**

Full-stack document intelligence platform that transforms Apriso MES documents
into RAG-ready Markdown packages for EVA / OpenAI / Azure AI Search.

---

## Stack

| Layer | Tech |
|---|---|
| API | FastAPI + Uvicorn |
| Worker | Celery + Redis |
| Extraction | Docling (primary) + fallback text extractor |
| OCR | PaddleOCR |
| Database | PostgreSQL 15 |
| Storage | MinIO (S3-compatible) |
| Frontend | Single HTML file — no build step |

---

## Quick start (Docker — recommended)

```bash
# 1. Clone / unzip this folder
cd knowledge-compiler-studio

# 2. Start everything
docker compose up --build

# 3. Open browser
# Frontend:  http://localhost:3000
# API docs:  http://localhost:8000/docs
# MinIO UI:  http://localhost:9001  (user: kcs_minio_user / pass: kcs_minio_secret)
# Flower:    http://localhost:5555
```

First startup takes 3–5 min (Docling + PaddleOCR download their models).

---

## Local dev (no Docker)

```bash
# Prerequisites: Python 3.11+, PostgreSQL, Redis, MinIO running locally

cd backend
pip install -r requirements.txt

# Create .env
cp .env.example .env   # edit DB/Redis/MinIO URLs

# Run API
uvicorn app.main:app --reload --port 8000

# Run worker (separate terminal)
celery -A app.worker.celery_app worker --loglevel=info -Q kcs_jobs

# Serve frontend (any static server)
cd ../frontend
python -m http.server 3000
```

---

## API endpoints

| Method | Path | Description |
|---|---|---|
| POST | /api/v1/upload | Upload + queue document |
| GET | /api/v1/job/{id} | Poll job status & results |
| GET | /api/v1/jobs | List recent jobs |
| GET | /api/v1/job/{id}/markdown | Get markdown + metadata |
| GET | /api/v1/job/{id}/download | Download ZIP package |
| DELETE | /api/v1/job/{id} | Delete job |
| GET | /api/v1/health | Health check |

---

## Supported input formats

PDF · DOCX · PPTX · XLSX · CSV · TXT · HTML · MD

---

## Apriso document types (auto-detected)

- NCR / Issue Report → `mes-ncr-triplet` chunk strategy
- CAPA Document → `mes-capa-triplet`
- Work Instruction → `procedure-aware`
- Maintenance Plan (CMMS) → `equipment-boundary`
- OEE Report → `kpi-boundary`
- KB Article / Support Ticket → `mes-kb-triplet`
- Production Order → `order-boundary`
- Apriso Config Doc → `section-boundary`

---

## Export package structure

```
knowledge-package/
  document.md          ← chunked markdown with CHUNK_START/END markers
  metadata.yaml        ← ISA-95 + Apriso module context
  eva-config.json      ← EVA/RAG collection + embedding + path config
  audit.json           ← full provenance trail
```

---

## Environment variables (.env)

```
DATABASE_URL=postgresql+asyncpg://kcs_user:kcs_secret@localhost:5432/kcs_db
REDIS_URL=redis://localhost:6379/0
MINIO_ENDPOINT=localhost:9000
MINIO_ACCESS_KEY=kcs_minio_user
MINIO_SECRET_KEY=kcs_minio_secret
MINIO_SECURE=false
SECRET_KEY=change-me-in-production-32chars!!
```
