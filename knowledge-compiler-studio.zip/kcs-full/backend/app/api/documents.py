"""
Documents API: upload, status, results, download.
"""
import uuid
import logging
from pathlib import Path
from typing import List, Optional

from fastapi import APIRouter, UploadFile, File, HTTPException, Depends, Query
from fastapi.responses import StreamingResponse, JSONResponse
from pydantic import BaseModel
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, desc
import aiofiles
import tempfile

from app.core.database import get_db
from app.models.document import Document, AuditLog, JobStatus
from app.services.storage import upload_file, download_file, get_presigned_url
from app.worker.tasks import process_document

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/api/documents", tags=["documents"])

ALLOWED_EXTENSIONS = {".pdf", ".docx", ".doc", ".pptx", ".xlsx", ".csv", ".txt", ".html", ".md"}
MAX_FILE_SIZE = 50 * 1024 * 1024  # 50 MB

class DocumentResponse(BaseModel):
    id: str
    filename: str
    original_name: str
    mime_type: str
    file_size: int
    status: str
    apriso_module: str
    doc_type: Optional[str]
    page_count: int
    word_count: int
    table_count: int
    image_count: int
    chunk_count: int
    ocr_confidence: float
    progress: int
    progress_msg: str
    created_at: str
    updated_at: str
    error_msg: Optional[str]

    class Config:
        from_attributes = True

def doc_to_response(doc: Document) -> dict:
    return {
        "id": doc.id,
        "filename": doc.filename,
        "original_name": doc.original_name,
        "mime_type": doc.mime_type,
        "file_size": doc.file_size,
        "status": doc.status,
        "apriso_module": doc.apriso_module,
        "doc_type": doc.doc_type,
        "page_count": doc.page_count,
        "word_count": doc.word_count,
        "table_count": doc.table_count,
        "image_count": doc.image_count,
        "chunk_count": doc.chunk_count,
        "ocr_confidence": doc.ocr_confidence,
        "progress": doc.progress,
        "progress_msg": doc.progress_msg,
        "created_at": doc.created_at.isoformat() if doc.created_at else "",
        "updated_at": doc.updated_at.isoformat() if doc.updated_at else "",
        "error_msg": doc.error_msg,
    }

@router.post("/upload")
async def upload_document(
    file: UploadFile = File(...),
    db: AsyncSession = Depends(get_db),
):
    """Upload a document and queue it for processing."""
    # Validate extension
    suffix = Path(file.filename).suffix.lower()
    if suffix not in ALLOWED_EXTENSIONS:
        raise HTTPException(400, f"File type '{suffix}' not supported. Allowed: {', '.join(ALLOWED_EXTENSIONS)}")

    # Read file
    file_bytes = await file.read()
    if len(file_bytes) > MAX_FILE_SIZE:
        raise HTTPException(413, f"File too large. Max size: {MAX_FILE_SIZE // 1024 // 1024} MB")
    if not file_bytes:
        raise HTTPException(400, "Empty file")

    # Build MinIO key
    doc_id = str(uuid.uuid4())
    safe_name = f"{doc_id}{suffix}"
    minio_key = f"uploads/{doc_id}/{safe_name}"

    # Upload to MinIO
    try:
        upload_file(minio_key, file_bytes, file.content_type or "application/octet-stream")
    except Exception as e:
        raise HTTPException(500, f"Storage error: {e}")

    # Create DB record
    doc = Document(
        id=doc_id,
        filename=safe_name,
        original_name=file.filename,
        mime_type=file.content_type or "application/octet-stream",
        file_size=len(file_bytes),
        minio_key=minio_key,
        status=JobStatus.QUEUED,
        progress=0,
        progress_msg="Queued for processing",
    )
    db.add(doc)

    # Audit
    audit = AuditLog(doc_id=doc_id, event="upload", detail=f"size={len(file_bytes)} type={suffix}")
    db.add(audit)
    await db.flush()

    # Queue Celery task
    task = process_document.apply_async(
        args=[doc_id, minio_key, file.filename],
        queue="kcs_jobs",
    )
    doc.celery_task_id = task.id
    doc.status = JobStatus.QUEUED

    logger.info(f"Queued doc {doc_id} task {task.id}")
    return {"doc_id": doc_id, "task_id": task.id, "status": "queued", "filename": file.filename}

@router.get("/")
async def list_documents(
    limit: int = Query(50, ge=1, le=200),
    offset: int = Query(0, ge=0),
    status: Optional[str] = None,
    db: AsyncSession = Depends(get_db),
):
    q = select(Document).order_by(desc(Document.created_at)).limit(limit).offset(offset)
    if status:
        q = q.where(Document.status == status)
    result = await db.execute(q)
    docs = result.scalars().all()
    return [doc_to_response(d) for d in docs]

@router.get("/{doc_id}")
async def get_document(doc_id: str, db: AsyncSession = Depends(get_db)):
    result = await db.execute(select(Document).where(Document.id == doc_id))
    doc = result.scalar_one_or_none()
    if not doc:
        raise HTTPException(404, "Document not found")
    return doc_to_response(doc)

@router.get("/{doc_id}/progress")
async def get_progress(doc_id: str, db: AsyncSession = Depends(get_db)):
    """Polling endpoint for progress — also checks Redis for latest."""
    result = await db.execute(select(Document).where(Document.id == doc_id))
    doc = result.scalar_one_or_none()
    if not doc:
        raise HTTPException(404, "Document not found")

    # Try Redis for freshest update
    try:
        import redis, json
        from app.core.config import settings
        r = redis.from_url(settings.REDIS_URL)
        raw = r.get(f"kcs:progress:latest:{doc_id}")
        if raw:
            latest = json.loads(raw)
            return {
                "doc_id": doc_id,
                "status": doc.status,
                "progress": latest.get("pct", doc.progress),
                "message": latest.get("msg", doc.progress_msg),
            }
    except Exception:
        pass

    return {
        "doc_id": doc_id,
        "status": doc.status,
        "progress": doc.progress,
        "message": doc.progress_msg,
    }

@router.get("/{doc_id}/markdown")
async def get_markdown(doc_id: str, db: AsyncSession = Depends(get_db)):
    result = await db.execute(select(Document).where(Document.id == doc_id))
    doc = result.scalar_one_or_none()
    if not doc:
        raise HTTPException(404, "Document not found")
    if doc.status != "done":
        raise HTTPException(400, f"Document not ready (status: {doc.status})")
    if not doc.markdown_key:
        raise HTTPException(404, "Markdown output not found")
    try:
        md_bytes = download_file(doc.markdown_key)
        return {"markdown": md_bytes.decode("utf-8", errors="replace")}
    except Exception as e:
        raise HTTPException(500, f"Could not retrieve markdown: {e}")

@router.get("/{doc_id}/metadata")
async def get_metadata(doc_id: str, db: AsyncSession = Depends(get_db)):
    result = await db.execute(select(Document).where(Document.id == doc_id))
    doc = result.scalar_one_or_none()
    if not doc:
        raise HTTPException(404, "Document not found")
    import json
    meta = doc.metadata_json
    if isinstance(meta, str):
        meta = json.loads(meta)
    return meta or {}

@router.get("/{doc_id}/download/{file_type}")
async def download_package_file(
    doc_id: str,
    file_type: str,
    db: AsyncSession = Depends(get_db),
):
    """Download individual package file: markdown | metadata | eva-config | audit"""
    if file_type not in ("markdown", "metadata", "eva-config", "audit"):
        raise HTTPException(400, "file_type must be: markdown | metadata | eva-config | audit")

    result = await db.execute(select(Document).where(Document.id == doc_id))
    doc = result.scalar_one_or_none()
    if not doc:
        raise HTTPException(404)
    if doc.status != "done":
        raise HTTPException(400, f"Not ready: {doc.status}")

    file_map = {
        "markdown":   (f"output/{doc_id}/document.md",     "text/markdown",     "document.md"),
        "metadata":   (f"output/{doc_id}/metadata.yaml",   "text/yaml",         "metadata.yaml"),
        "eva-config": (f"output/{doc_id}/eva-config.json", "application/json",  "eva-config.json"),
        "audit":      (f"output/{doc_id}/audit.json",      "application/json",  "audit.json"),
    }
    key, content_type, dl_name = file_map[file_type]
    try:
        data = download_file(key)
        return StreamingResponse(
            iter([data]),
            media_type=content_type,
            headers={"Content-Disposition": f'attachment; filename="{dl_name}"'},
        )
    except Exception as e:
        raise HTTPException(500, f"Download error: {e}")

@router.delete("/{doc_id}")
async def delete_document(doc_id: str, db: AsyncSession = Depends(get_db)):
    result = await db.execute(select(Document).where(Document.id == doc_id))
    doc = result.scalar_one_or_none()
    if not doc:
        raise HTTPException(404)
    await db.delete(doc)
    return {"deleted": doc_id}
