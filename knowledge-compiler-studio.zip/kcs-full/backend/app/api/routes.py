import os, uuid, logging
from datetime import datetime
from pathlib import Path
from typing import Optional
from fastapi import APIRouter, UploadFile, File, HTTPException, Depends, Form
from fastapi.responses import StreamingResponse, JSONResponse
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, desc
import aiofiles, json

from app.models.database import get_db
from app.models.job import ProcessingJob
from app.services.storage import upload_file, download_file, get_presigned_url
from app.config import get_settings
from app.worker.tasks import process_job

logger = logging.getLogger(__name__)
settings = get_settings()
router = APIRouter()

ALLOWED_EXTENSIONS = {".pdf", ".docx", ".pptx", ".xlsx", ".csv", ".txt", ".html", ".md"}
MAX_BYTES = settings.max_upload_mb * 1024 * 1024


# ── POST /upload ─────────────────────────────────────────────────────────────
@router.post("/upload")
async def upload_document(
    file: UploadFile = File(...),
    extraction_engine: str = Form("docling"),
    ocr_engine: str = Form("paddleocr"),
    rules: str = Form("{}"),
    isa95_context: str = Form("{}"),
    db: AsyncSession = Depends(get_db),
):
    ext = Path(file.filename).suffix.lower()
    if ext not in ALLOWED_EXTENSIONS:
        raise HTTPException(400, f"Unsupported file type: {ext}")

    content = await file.read()
    if len(content) > MAX_BYTES:
        raise HTTPException(413, f"File too large. Maximum {settings.max_upload_mb} MB.")

    job_id = str(uuid.uuid4())
    safe_name = f"{job_id}{ext}"
    minio_key = f"uploads/{job_id}/{safe_name}"

    # Upload to MinIO
    upload_file(settings.minio_bucket_docs, minio_key, content, file.content_type or "application/octet-stream")

    # Parse config
    try:
        rules_dict = json.loads(rules)
        isa95_dict = json.loads(isa95_context)
    except json.JSONDecodeError:
        rules_dict = {}
        isa95_dict = {}

    # Create DB record
    job = ProcessingJob(
        id=job_id,
        filename=safe_name,
        original_filename=file.filename,
        file_size=len(content),
        mime_type=file.content_type or "",
        minio_doc_key=minio_key,
        status="pending",
        progress=0.0,
        current_step="Queued",
        extraction_engine=extraction_engine,
        ocr_engine=ocr_engine,
        rules_config=rules_dict,
        isa95_context=isa95_dict,
    )
    db.add(job)
    await db.commit()

    # Dispatch Celery task
    job_config = {
        "extraction_engine": extraction_engine,
        "ocr_engine": ocr_engine,
        "rules": rules_dict,
        "isa95_context": isa95_dict,
    }
    process_job.apply_async(
        args=[job_id, minio_key, ext, job_config],
        task_id=f"kcs-{job_id}",
    )

    return {"job_id": job_id, "status": "pending", "filename": file.filename}


# ── GET /job/{job_id} ────────────────────────────────────────────────────────
@router.get("/job/{job_id}")
async def get_job(job_id: str, db: AsyncSession = Depends(get_db)):
    result = await db.execute(select(ProcessingJob).where(ProcessingJob.id == job_id))
    job = result.scalar_one_or_none()
    if not job:
        raise HTTPException(404, "Job not found")
    return job.to_dict()


# ── GET /jobs ────────────────────────────────────────────────────────────────
@router.get("/jobs")
async def list_jobs(limit: int = 20, db: AsyncSession = Depends(get_db)):
    result = await db.execute(
        select(ProcessingJob).order_by(desc(ProcessingJob.created_at)).limit(limit)
    )
    jobs = result.scalars().all()
    return [j.to_dict() for j in jobs]


# ── GET /job/{job_id}/markdown ───────────────────────────────────────────────
@router.get("/job/{job_id}/markdown")
async def get_markdown(job_id: str, db: AsyncSession = Depends(get_db)):
    result = await db.execute(select(ProcessingJob).where(ProcessingJob.id == job_id))
    job = result.scalar_one_or_none()
    if not job:
        raise HTTPException(404, "Job not found")
    if job.status != "complete":
        raise HTTPException(400, f"Job not complete (status: {job.status})")
    return {"markdown": job.markdown_content, "metadata_yaml": job.metadata_yaml, "eva_config": job.eva_config}


# ── GET /job/{job_id}/download ───────────────────────────────────────────────
@router.get("/job/{job_id}/download")
async def download_package(job_id: str, db: AsyncSession = Depends(get_db)):
    result = await db.execute(select(ProcessingJob).where(ProcessingJob.id == job_id))
    job = result.scalar_one_or_none()
    if not job:
        raise HTTPException(404, "Job not found")
    if job.status != "complete" or not job.minio_package_key:
        raise HTTPException(400, "Package not ready")

    zip_bytes = download_file(settings.minio_bucket_packages, job.minio_package_key)
    safe_name = Path(job.original_filename).stem

    return StreamingResponse(
        iter([zip_bytes]),
        media_type="application/zip",
        headers={"Content-Disposition": f'attachment; filename="kcs-{safe_name}.zip"'},
    )


# ── DELETE /job/{job_id} ─────────────────────────────────────────────────────
@router.delete("/job/{job_id}")
async def delete_job(job_id: str, db: AsyncSession = Depends(get_db)):
    result = await db.execute(select(ProcessingJob).where(ProcessingJob.id == job_id))
    job = result.scalar_one_or_none()
    if not job:
        raise HTTPException(404, "Job not found")
    await db.delete(job)
    await db.commit()
    return {"deleted": job_id}


# ── GET /health ──────────────────────────────────────────────────────────────
@router.get("/health")
async def health():
    return {"status": "ok", "app": "Knowledge Compiler Studio", "version": "1.0.0"}
