from pydantic_settings import BaseSettings
from functools import lru_cache

class Settings(BaseSettings):
    # App
    app_name: str = "Knowledge Compiler Studio"
    secret_key: str = "change-me-in-production-32chars!!"
    debug: bool = False

    # Database
    database_url: str = "postgresql+asyncpg://kcs_user:kcs_secret@localhost:5432/kcs_db"

    # Redis / Celery
    redis_url: str = "redis://localhost:6379/0"

    # MinIO
    minio_endpoint: str = "localhost:9000"
    minio_access_key: str = "kcs_minio_user"
    minio_secret_key: str = "kcs_minio_secret"
    minio_secure: bool = False
    minio_bucket_docs: str = "kcs-documents"
    minio_bucket_packages: str = "kcs-packages"
    minio_bucket_images: str = "kcs-images"

    # Processing
    max_upload_mb: int = 100
    upload_tmp_dir: str = "/tmp/kcs_uploads"

    class Config:
        env_file = ".env"
        case_sensitive = False

@lru_cache()
def get_settings() -> Settings:
    return Settings()
