import uuid
from datetime import datetime
from sqlalchemy import String, DateTime, Integer, Float, Text, JSON, Enum as SAEnum
from sqlalchemy.orm import Mapped, mapped_column
from app.core.database import Base
import enum

class JobStatus(str, enum.Enum):
    PENDING   = "pending"
    UPLOADING = "uploading"
    QUEUED    = "queued"
    EXTRACTING= "extracting"
    PARSING   = "parsing"
    CHUNKING  = "chunking"
    TAGGING   = "tagging"
    DONE      = "done"
    FAILED    = "failed"

class AprisoModule(str, enum.Enum):
    PRODUCTION  = "production"
    QUALITY     = "quality"
    MAINTENANCE = "maintenance"
    OEE         = "oee"
    ISSUE       = "issue_mgmt"
    KB          = "knowledge_base"
    CONFIG      = "configuration"
    UNKNOWN     = "unknown"

class Document(Base):
    __tablename__ = "documents"

    id:            Mapped[str]   = mapped_column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    filename:      Mapped[str]   = mapped_column(String(512))
    original_name: Mapped[str]   = mapped_column(String(512))
    mime_type:     Mapped[str]   = mapped_column(String(128))
    file_size:     Mapped[int]   = mapped_column(Integer)
    minio_key:     Mapped[str]   = mapped_column(String(1024))
    status:        Mapped[str]   = mapped_column(SAEnum(JobStatus), default=JobStatus.PENDING)
    apriso_module: Mapped[str]   = mapped_column(SAEnum(AprisoModule), default=AprisoModule.UNKNOWN)
    doc_type:      Mapped[str]   = mapped_column(String(128), nullable=True)
    page_count:    Mapped[int]   = mapped_column(Integer, default=0)
    word_count:    Mapped[int]   = mapped_column(Integer, default=0)
    table_count:   Mapped[int]   = mapped_column(Integer, default=0)
    image_count:   Mapped[int]   = mapped_column(Integer, default=0)
    chunk_count:   Mapped[int]   = mapped_column(Integer, default=0)
    ocr_confidence:Mapped[float] = mapped_column(Float, default=0.0)
    celery_task_id:Mapped[str]   = mapped_column(String(128), nullable=True)
    progress:      Mapped[int]   = mapped_column(Integer, default=0)
    progress_msg:  Mapped[str]   = mapped_column(String(256), default="")
    markdown_key:  Mapped[str]   = mapped_column(String(1024), nullable=True)
    metadata_json: Mapped[dict]  = mapped_column(JSON, default=dict)
    error_msg:     Mapped[str]   = mapped_column(Text, nullable=True)
    created_at:    Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)
    updated_at:    Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

class AuditLog(Base):
    __tablename__ = "audit_logs"

    id:         Mapped[str]      = mapped_column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    doc_id:     Mapped[str]      = mapped_column(String(36))
    event:      Mapped[str]      = mapped_column(String(128))
    detail:     Mapped[str]      = mapped_column(Text, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)
