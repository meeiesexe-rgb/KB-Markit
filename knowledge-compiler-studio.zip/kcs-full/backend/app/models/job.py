import uuid
from datetime import datetime
from sqlalchemy import String, DateTime, Integer, Float, Text, JSON
from sqlalchemy.orm import Mapped, mapped_column
from app.models.database import Base

class ProcessingJob(Base):
    __tablename__ = "processing_jobs"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    filename: Mapped[str] = mapped_column(String(512))
    original_filename: Mapped[str] = mapped_column(String(512))
    file_size: Mapped[int] = mapped_column(Integer, default=0)
    mime_type: Mapped[str] = mapped_column(String(128), default="")
    minio_doc_key: Mapped[str] = mapped_column(String(1024), default="")

    # Status: pending | processing | complete | failed
    status: Mapped[str] = mapped_column(String(32), default="pending")
    progress: Mapped[float] = mapped_column(Float, default=0.0)
    current_step: Mapped[str] = mapped_column(String(128), default="Queued")
    error_message: Mapped[str] = mapped_column(Text, default="")

    # Detection results
    detected_doc_type: Mapped[str] = mapped_column(String(128), default="")
    detected_apriso_module: Mapped[str] = mapped_column(String(128), default="")
    page_count: Mapped[int] = mapped_column(Integer, default=0)
    word_count: Mapped[int] = mapped_column(Integer, default=0)
    table_count: Mapped[int] = mapped_column(Integer, default=0)
    image_count: Mapped[int] = mapped_column(Integer, default=0)
    ocr_confidence: Mapped[float] = mapped_column(Float, default=0.0)

    # Config used
    extraction_engine: Mapped[str] = mapped_column(String(64), default="docling")
    ocr_engine: Mapped[str] = mapped_column(String(64), default="paddleocr")
    rules_config: Mapped[dict] = mapped_column(JSON, default=dict)
    isa95_context: Mapped[dict] = mapped_column(JSON, default=dict)

    # Output
    markdown_content: Mapped[str] = mapped_column(Text, default="")
    metadata_yaml: Mapped[str] = mapped_column(Text, default="")
    eva_config: Mapped[dict] = mapped_column(JSON, default=dict)
    chunk_count: Mapped[int] = mapped_column(Integer, default=0)
    token_estimate: Mapped[int] = mapped_column(Integer, default=0)
    minio_package_key: Mapped[str] = mapped_column(String(1024), default="")

    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)
    updated_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    completed_at: Mapped[datetime] = mapped_column(DateTime, nullable=True)

    def to_dict(self):
        return {
            "id": self.id,
            "filename": self.filename,
            "original_filename": self.original_filename,
            "file_size": self.file_size,
            "mime_type": self.mime_type,
            "status": self.status,
            "progress": self.progress,
            "current_step": self.current_step,
            "error_message": self.error_message,
            "detected_doc_type": self.detected_doc_type,
            "detected_apriso_module": self.detected_apriso_module,
            "page_count": self.page_count,
            "word_count": self.word_count,
            "table_count": self.table_count,
            "image_count": self.image_count,
            "ocr_confidence": self.ocr_confidence,
            "extraction_engine": self.extraction_engine,
            "ocr_engine": self.ocr_engine,
            "markdown_content": self.markdown_content,
            "metadata_yaml": self.metadata_yaml,
            "eva_config": self.eva_config,
            "chunk_count": self.chunk_count,
            "token_estimate": self.token_estimate,
            "isa95_context": self.isa95_context,
            "created_at": self.created_at.isoformat() if self.created_at else None,
            "completed_at": self.completed_at.isoformat() if self.completed_at else None,
        }
