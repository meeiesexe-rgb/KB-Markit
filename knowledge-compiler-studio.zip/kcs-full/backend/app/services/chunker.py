"""
RAG-aware chunker with Apriso MES-specific strategies.
Supports: procedure-aware, NCR-triplet, KB-triplet, and standard heading-based chunking.
"""
import re
import uuid
from dataclasses import dataclass, field
from typing import List

@dataclass
class Chunk:
    id: str = field(default_factory=lambda: str(uuid.uuid4())[:8])
    strategy: str = "heading"
    heading: str = ""
    content: str = ""
    token_estimate: int = 0
    sequence: int = 0
    metadata: dict = field(default_factory=dict)

    def to_markdown(self) -> str:
        tok = self.token_estimate
        return (
            f"\n<!-- CHUNK_START id:{self.id} strategy:{self.strategy} tokens:~{tok} -->\n"
            f"{self.content}\n"
            f"<!-- CHUNK_END -->\n"
        )

def estimate_tokens(text: str) -> int:
    return max(1, int(len(text.split()) * 1.35))

def chunk_document(markdown: str, apriso_module: str, doc_type: str) -> List[Chunk]:
    """Route to the right chunking strategy based on Apriso module + doc type."""
    if doc_type in ("NCR Report", "RCA Report", "CAPA Document"):
        return _chunk_ncr_triplet(markdown)
    elif doc_type in ("KB Article", "Support Ticket"):
        return _chunk_kb_triplet(markdown)
    elif doc_type == "Work Instruction":
        return _chunk_procedure(markdown)
    else:
        return _chunk_headings(markdown)

def _chunk_headings(markdown: str) -> List[Chunk]:
    """Standard heading-boundary chunking."""
    chunks = []
    current_heading = "Overview"
    current_lines = []

    def flush(heading, lines, seq):
        if not lines:
            return
        content = "\n".join(lines).strip()
        if not content:
            return
        chunks.append(Chunk(
            strategy="heading",
            heading=heading,
            content=f"### {heading}\n\n{content}" if heading else content,
            token_estimate=estimate_tokens(content),
            sequence=seq,
        ))

    seq = 0
    for line in markdown.splitlines():
        if re.match(r"^#{1,3} ", line):
            flush(current_heading, current_lines, seq)
            seq += 1
            current_heading = re.sub(r"^#+\s*", "", line).strip()
            current_lines = []
        else:
            current_lines.append(line)

    flush(current_heading, current_lines, seq)
    return chunks

def _chunk_procedure(markdown: str) -> List[Chunk]:
    """Chunk on numbered steps — each step becomes a chunk."""
    chunks = []
    step_pattern = re.compile(r"^(step\s+\d+|^\d+\.\s|\b[a-z]\.\s)", re.IGNORECASE | re.MULTILINE)
    parts = step_pattern.split(markdown)
    # Combine prefix back
    combined = []
    i = 0
    while i < len(parts):
        if step_pattern.match(parts[i]):
            combined.append(parts[i] + (parts[i+1] if i+1 < len(parts) else ""))
            i += 2
        else:
            if parts[i].strip():
                combined.append(parts[i])
            i += 1

    for seq, block in enumerate(combined):
        block = block.strip()
        if not block:
            continue
        heading = block.splitlines()[0][:80] if block else f"Step {seq+1}"
        chunks.append(Chunk(
            strategy="procedure-step",
            heading=heading,
            content=block,
            token_estimate=estimate_tokens(block),
            sequence=seq,
        ))
    return chunks or _chunk_headings(markdown)

def _chunk_ncr_triplet(markdown: str) -> List[Chunk]:
    """
    NCR/CAPA triplet strategy:
    Chunk 1: Issue identification (header, defect info)
    Chunk 2: Root cause analysis
    Chunk 3: Corrective / preventive actions
    Chunk 4+: Any remaining sections
    """
    text = markdown
    chunks = []

    patterns = {
        "issue-identification": r"(issue.identif|NCR.header|defect.summ|non.conform)",
        "root-cause":           r"(root.cause|RCA|5.why|fishbone|why\s+\d+)",
        "capa":                 r"(corrective.*action|CAPA|preventive.*action|disposition)",
        "oee-impact":           r"(OEE|production.impact|downtime|quality.loss)",
    }

    remaining = text
    seq = 0
    for strategy_name, pattern in patterns.items():
        match = re.search(pattern, remaining, re.IGNORECASE)
        if match:
            pre = remaining[:match.start()].strip()
            # Find end of this section = next section heading
            next_section = re.search(r"\n#{1,3} ", remaining[match.start()+1:])
            if next_section:
                end = match.start() + 1 + next_section.start()
            else:
                end = len(remaining)
            block = remaining[match.start():end].strip()
            if block:
                chunks.append(Chunk(
                    strategy=f"mes-ncr-{strategy_name}",
                    heading=strategy_name.replace("-", " ").title(),
                    content=block,
                    token_estimate=estimate_tokens(block),
                    sequence=seq,
                ))
                seq += 1
            remaining = remaining[end:]

    if remaining.strip():
        chunks.append(Chunk(
            strategy="mes-ncr-remainder",
            heading="Additional information",
            content=remaining.strip(),
            token_estimate=estimate_tokens(remaining),
            sequence=seq,
        ))

    return chunks or _chunk_headings(markdown)

def _chunk_kb_triplet(markdown: str) -> List[Chunk]:
    """
    KB/support ticket triplet strategy:
    Chunk on Symptom → Root Cause / Analysis → Resolution / Workaround
    """
    chunks = []
    patterns = {
        "symptom":    r"(symptom|problem.desc|issue.desc|error.message|behaviour)",
        "cause":      r"(cause|analysis|diagnosis|root.cause|investigation)",
        "resolution": r"(resolution|solution|fix|workaround|steps.to.resolve)",
    }
    remaining = markdown
    seq = 0
    for section, pattern in patterns.items():
        match = re.search(pattern, remaining, re.IGNORECASE)
        if match:
            next_s = re.search(r"\n#{1,3} ", remaining[match.start()+1:])
            end = match.start() + 1 + next_s.start() if next_s else len(remaining)
            block = remaining[match.start():end].strip()
            if block:
                chunks.append(Chunk(
                    strategy=f"mes-kb-{section}",
                    heading=section.title(),
                    content=block,
                    token_estimate=estimate_tokens(block),
                    sequence=seq,
                ))
                seq += 1
            remaining = remaining[end:]
    if remaining.strip():
        chunks.append(Chunk(
            strategy="mes-kb-meta",
            heading="Metadata & references",
            content=remaining.strip(),
            token_estimate=estimate_tokens(remaining),
            sequence=seq,
        ))
    return chunks or _chunk_headings(markdown)

def chunks_to_markdown(chunks: List[Chunk]) -> str:
    parts = []
    for chunk in chunks:
        parts.append(chunk.to_markdown())
    return "\n".join(parts)
