"""
Apriso MES document classifier.
Heuristic-based — no LLM required. Pure regex + keyword scoring.
"""
import re
from dataclasses import dataclass
from typing import Tuple

@dataclass
class ClassificationResult:
    apriso_module: str
    doc_type: str
    confidence: float
    signals: list

# Module keyword weights
MODULE_SIGNALS = {
    "issue_mgmt": [
        (r"\bNCR\b", 3.0), (r"non.?conforman", 3.0), (r"defect code", 2.5),
        (r"DEF-[A-Z]{2,}-\d+", 3.0), (r"disposition", 2.0), (r"containment", 2.0),
        (r"8D\b", 2.5), (r"severity.*(major|minor|critical)", 2.0),
    ],
    "quality": [
        (r"\bCAPR?\b", 2.5), (r"corrective.action", 2.5), (r"preventive.action", 2.5),
        (r"inspection plan", 2.5), (r"control plan", 2.0), (r"SPC\b", 2.0),
        (r"first.article", 2.0), (r"quality.plan", 2.0), (r"audit.checklist", 2.0),
        (r"root.cause", 2.0), (r"fishbone|ishikawa", 2.5), (r"5.why", 2.0),
    ],
    "maintenance": [
        (r"preventive.maintenance\b", 3.0), (r"\bPM\b.*schedule", 2.5),
        (r"work.order\b", 2.0), (r"calibration", 2.5), (r"equipment.id\b", 2.0),
        (r"CMMS\b", 3.0), (r"spare.part", 2.0), (r"FMEA\b", 2.5),
        (r"failure.mode", 2.0), (r"service.interval", 2.5),
    ],
    "oee": [
        (r"\bOEE\b", 3.0), (r"availability.*performance.*quality", 3.0),
        (r"downtime.categor", 2.5), (r"planned.downtime", 2.0), (r"loss.tree", 2.5),
        (r"shift.report", 2.0), (r"throughput", 1.5), (r"cycle.time", 1.5),
        (r"takt.time", 2.0),
    ],
    "production": [
        (r"work.instruction", 3.0), (r"operation.card", 2.5), (r"routing", 2.0),
        (r"production.order\b", 2.5), (r"BOM\b", 2.0), (r"WIP\b", 2.0),
        (r"dispatch.list", 2.0), (r"operator.certif", 2.0), (r"assembly.sequence", 2.5),
    ],
    "knowledge_base": [
        (r"symptom", 2.5), (r"resolution\b", 2.5), (r"workaround", 2.5),
        (r"affected.version", 2.5), (r"known.issue", 2.5), (r"FlexNet\b", 3.0),
        (r"release.note", 2.5), (r"troubleshoot", 2.5), (r"KB-\d+", 3.0),
        (r"ticket.id\b", 2.5),
    ],
    "configuration": [
        (r"FlexNet\b", 3.0), (r"apriso.process\b", 3.0), (r"activity\b.*container\b", 2.5),
        (r"field.definition", 2.0), (r"process.designer", 2.5), (r"web.service\b", 2.0),
        (r"configuration.guide", 2.5),
    ],
}

DOC_TYPE_PATTERNS = {
    "NCR Report":         [r"\bNCR\b", r"non.?conforman", r"DEF-[A-Z]+-\d+"],
    "CAPA Document":      [r"\bCAP[AR]\b", r"corrective.*preventive", r"effectiveness.check"],
    "Work Instruction":   [r"work.instruction", r"step \d+.*:", r"operator.certif"],
    "Maintenance Plan":   [r"PM.schedule", r"preventive.maintenance", r"service.interval"],
    "OEE Report":         [r"\bOEE\b", r"availability.*performance", r"downtime.loss"],
    "KB Article":         [r"symptom.*resolution", r"workaround", r"FlexNet.*error"],
    "Support Ticket":     [r"ticket.id\b", r"priority.*high|medium|low", r"status.*open|closed"],
    "Production Order":   [r"production.order", r"quantity.*\d+", r"line.*schedule"],
    "Quality Plan":       [r"control.plan", r"inspection.plan", r"SPC\b"],
    "Apriso Config Doc":  [r"FlexNet\b", r"process.designer", r"activity.*field"],
    "Release Notes":      [r"version \d+\.\d+", r"fixed.*issue", r"known.issues"],
    "RCA Report":         [r"root.cause", r"5.why|fishbone", r"corrective.action"],
}

def classify(text: str) -> ClassificationResult:
    text_lower = text.lower()
    module_scores = {}
    all_signals = []

    for module, patterns in MODULE_SIGNALS.items():
        score = 0.0
        hits = []
        for pattern, weight in patterns:
            matches = len(re.findall(pattern, text_lower, re.IGNORECASE))
            if matches:
                score += weight * min(matches, 3)
                hits.append(pattern)
        module_scores[module] = score
        if hits:
            all_signals.extend(hits[:3])

    # Pick top module
    top_module = max(module_scores, key=module_scores.get) if module_scores else "unknown"
    top_score = module_scores.get(top_module, 0.0)
    total_score = sum(module_scores.values()) or 1
    confidence = min(0.98, top_score / total_score * 2.5) if top_score > 0 else 0.5

    # Issue mgmt + quality often co-occur; keep both signal
    if module_scores.get("issue_mgmt", 0) > 0 and module_scores.get("quality", 0) > 0:
        if module_scores["issue_mgmt"] >= module_scores["quality"]:
            top_module = "issue_mgmt"
        else:
            top_module = "quality"

    # Detect doc type
    doc_type = "Document"
    for dtype, patterns in DOC_TYPE_PATTERNS.items():
        hits = sum(1 for p in patterns if re.search(p, text_lower, re.IGNORECASE))
        if hits >= 2:
            doc_type = dtype
            break

    return ClassificationResult(
        apriso_module=top_module,
        doc_type=doc_type,
        confidence=round(confidence, 2),
        signals=list(set(all_signals))[:8],
    )
