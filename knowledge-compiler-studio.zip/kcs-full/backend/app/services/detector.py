"""
Apriso MES document type fingerprinting.
Heuristic-based — no LLM required.
"""
import re
from typing import Tuple

PATTERNS = {
    "ncr": {
        "apriso_module": "Issue Management",
        "keywords": ["non-conformance", "ncr", "defect code", "disposition", "rejection", "nonconforming"],
        "codes": [r"NCR-\w+", r"DEF-\w+", r"DISP-\w+"],
        "weight": 0,
    },
    "capa": {
        "apriso_module": "Quality Management",
        "keywords": ["corrective action", "preventive action", "capa", "root cause", "5-why", "fishbone", "8d"],
        "codes": [r"CAPA-\w+", r"CA-\w+"],
        "weight": 0,
    },
    "work_instruction": {
        "apriso_module": "Production Execution",
        "keywords": ["work instruction", "standard operating", "operation", "step", "procedure", "safety warning"],
        "codes": [r"WI-\w+", r"SOP-\w+", r"OP-\w+"],
        "weight": 0,
    },
    "maintenance_plan": {
        "apriso_module": "CMMS / Maintenance",
        "keywords": ["preventive maintenance", "pm schedule", "calibration", "torque", "lubrication", "work order", "cmms"],
        "codes": [r"WO-\w+", r"PM-\w+", r"EQ-\w+", r"ASSET-\w+"],
        "weight": 0,
    },
    "oee_report": {
        "apriso_module": "OEE & Performance",
        "keywords": ["oee", "overall equipment effectiveness", "availability", "performance rate", "quality rate",
                     "planned downtime", "unplanned downtime", "loss tree"],
        "codes": [r"LINE-\w+", r"SHIFT-\w+"],
        "weight": 0,
    },
    "kb_article": {
        "apriso_module": "Service & Support KB",
        "keywords": ["resolution", "symptoms", "affected version", "workaround", "known issue", "troubleshoot",
                     "knowledge base", "kb article"],
        "codes": [r"KB-\w+", r"TICKET-\w+", r"INC-\w+"],
        "weight": 0,
    },
    "production_order": {
        "apriso_module": "Production Execution",
        "keywords": ["production order", "work order", "routing", "bom", "bill of material", "dispatch", "wip"],
        "codes": [r"PO-\w+", r"WO-\w+", r"OP-\d+"],
        "weight": 0,
    },
    "apriso_config": {
        "apriso_module": "Apriso Configuration",
        "keywords": ["flexnet", "process definition", "activity", "container", "operation definition", "apriso"],
        "codes": [r"PROC-\w+", r"ACT-\w+"],
        "weight": 0,
    },
}

CHUNK_STRATEGIES = {
    "ncr": "mes-ncr-triplet",
    "capa": "mes-capa-triplet",
    "kb_article": "mes-kb-triplet",
    "work_instruction": "procedure-aware",
    "maintenance_plan": "equipment-boundary",
    "oee_report": "kpi-boundary",
    "production_order": "order-boundary",
    "apriso_config": "section-boundary",
}

TYPE_LABELS = {
    "ncr": "NCR / Issue Report",
    "capa": "CAPA Document",
    "work_instruction": "Work Instruction",
    "maintenance_plan": "Maintenance Plan",
    "oee_report": "OEE Report",
    "kb_article": "KB Article / Support Ticket",
    "production_order": "Production Order",
    "apriso_config": "Apriso Config Doc",
}

def detect_document_type(text: str) -> Tuple[str, str, str, float]:
    """
    Returns: (doc_type_key, doc_type_label, apriso_module, confidence_pct)
    """
    text_lower = text.lower()
    scores = {}

    for dtype, cfg in PATTERNS.items():
        score = 0
        for kw in cfg["keywords"]:
            if kw in text_lower:
                score += 10
        for pattern in cfg["codes"]:
            matches = re.findall(pattern, text, re.IGNORECASE)
            score += len(matches) * 8
        scores[dtype] = score

    if not any(scores.values()):
        return "work_instruction", "Work Instruction", "Production Execution", 0.45

    best = max(scores, key=scores.get)
    total = sum(scores.values()) or 1
    conf = min(scores[best] / total, 0.97)

    return best, TYPE_LABELS[best], PATTERNS[best]["apriso_module"], round(conf, 2)

def extract_apriso_codes(text: str) -> list[dict]:
    """Extract all Apriso-specific codes from document text."""
    code_patterns = [
        (r"NCR-[A-Z0-9\-]+", "Issue", "mt-issue"),
        (r"DEF-[A-Z0-9\-]+", "Defect code", "mt-qual"),
        (r"CAPA-[A-Z0-9\-]+", "CAPA ref", "mt-qual"),
        (r"WO-[A-Z0-9\-]+", "Work order", "mt-code"),
        (r"PO-[A-Z0-9\-]+", "Production order", "mt-proc"),
        (r"EQ-[A-Z0-9\-]+", "Equipment ID", "mt-equip"),
        (r"PM-[A-Z0-9\-]+", "PM schedule", "mt-equip"),
        (r"IP-[A-Z0-9\-]+", "Inspection plan", "mt-code"),
        (r"DISP-[A-Z0-9\-]+", "Disposition", "mt-qual"),
        (r"LINE-[A-Z0-9\-]+", "Production line", "mt-proc"),
        (r"WC-[A-Z0-9\-]+", "Work center", "mt-code"),
        (r"ASSET-[A-Z0-9\-]+", "Asset ID", "mt-equip"),
        (r"KB-[A-Z0-9\-]+", "KB article", "mt-code"),
    ]
    found = []
    seen = set()
    for pattern, label, css_class in code_patterns:
        for m in re.finditer(pattern, text, re.IGNORECASE):
            code = m.group().upper()
            if code not in seen:
                seen.add(code)
                found.append({"code": code, "label": label, "css_class": css_class})
    return found[:20]

def get_chunk_strategy(doc_type: str) -> str:
    return CHUNK_STRATEGIES.get(doc_type, "section-boundary")
