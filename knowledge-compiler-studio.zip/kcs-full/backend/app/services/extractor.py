"""
Document extraction service.
Primary: Docling  |  Fallback: basic text extraction
OCR: PaddleOCR (graceful fallback to pytesseract / raw text)
"""
import os, re, json, tempfile, logging
from pathlib import Path
from typing import Optional
from app.services.detector import detect_document_type, extract_apriso_codes, get_chunk_strategy

logger = logging.getLogger(__name__)

# ── Try importing Docling ───────────────────────────────────────────────────
try:
    from docling.document_converter import DocumentConverter, PdfFormatOption
    from docling.datamodel.base_models import InputFormat
    from docling.datamodel.pipeline_options import PdfPipelineOptions
    DOCLING_AVAILABLE = True
    logger.info("Docling available")
except ImportError:
    DOCLING_AVAILABLE = False
    logger.warning("Docling not installed — using fallback extractor")

# ── Try importing PaddleOCR ─────────────────────────────────────────────────
try:
    from paddleocr import PaddleOCR
    _paddle_instance = None
    PADDLE_AVAILABLE = True
    logger.info("PaddleOCR available")
except ImportError:
    PADDLE_AVAILABLE = False
    logger.warning("PaddleOCR not installed — OCR disabled")

def get_paddle():
    global _paddle_instance
    if _paddle_instance is None and PADDLE_AVAILABLE:
        _paddle_instance = PaddleOCR(use_angle_cls=True, lang="en", show_log=False)
    return _paddle_instance


def extract_with_docling(file_path: str, file_ext: str) -> dict:
    """Use Docling to extract structured content from PDF/DOCX/PPTX."""
    converter = DocumentConverter()
    result = converter.convert(file_path)
    doc = result.document

    # Export to markdown
    markdown = doc.export_to_markdown()

    # Collect metadata
    pages = getattr(doc, "pages", [])
    tables = [el for el in doc.iterate_items() if hasattr(el, "data") and hasattr(el.data, "num_rows")]
    pictures = [el for el in doc.iterate_items() if el.__class__.__name__ in ("PictureItem", "FigureItem")]

    return {
        "markdown": markdown,
        "page_count": len(pages) if pages else max(1, markdown.count("---")),
        "table_count": len(tables),
        "image_count": len(pictures),
        "word_count": len(markdown.split()),
    }


def extract_fallback(file_path: str, file_ext: str) -> dict:
    """Fallback text extraction for when Docling is unavailable."""
    ext = file_ext.lower()
    text = ""

    if ext == ".pdf":
        try:
            import pypdf
            reader = pypdf.PdfReader(file_path)
            pages_text = [p.extract_text() or "" for p in reader.pages]
            text = "\n\n".join(pages_text)
            page_count = len(reader.pages)
        except Exception:
            text = "(PDF text extraction failed — install pypdf)"
            page_count = 1

    elif ext in (".docx",):
        try:
            import docx
            doc = docx.Document(file_path)
            text = "\n\n".join(p.text for p in doc.paragraphs if p.text.strip())
            page_count = max(1, len(text) // 3000)
        except Exception:
            text = "(DOCX extraction failed)"
            page_count = 1

    elif ext in (".txt", ".md", ".html", ".csv"):
        with open(file_path, "r", errors="ignore") as f:
            text = f.read()
        page_count = max(1, len(text) // 3000)

    else:
        text = f"(Unsupported format for fallback extraction: {ext})"
        page_count = 1

    # Convert plain text to basic markdown
    lines = text.split("\n")
    md_lines = []
    for line in lines:
        line = line.strip()
        if not line:
            md_lines.append("")
        elif line.isupper() and len(line) < 80:
            md_lines.append(f"## {line.title()}")
        else:
            md_lines.append(line)
    markdown = "\n".join(md_lines)

    return {
        "markdown": markdown,
        "page_count": page_count,
        "table_count": markdown.count("|---"),
        "image_count": 0,
        "word_count": len(text.split()),
    }


def apply_text_rules(markdown: str, rules: dict) -> str:
    """Apply user-configured text transformation rules."""
    if rules.get("convert_caps_sentence"):
        def caps_to_sentence(m):
            word = m.group(0)
            return word[0].upper() + word[1:].lower() if len(word) > 3 else word
        markdown = re.sub(r'\b[A-Z]{4,}\b', caps_to_sentence, markdown)

    if rules.get("normalize_units"):
        replacements = {
            r'\bdegc\b': '°C', r'\bdegf\b': '°F',
            r'\bkpa\b': 'kPa', r'\bmpa\b': 'MPa',
            r'\brpm\b': 'RPM', r'\bcfm\b': 'CFM',
            r'\bn/m\b': 'N/m',
        }
        for pattern, replacement in replacements.items():
            markdown = re.sub(pattern, replacement, markdown, flags=re.IGNORECASE)

    if rules.get("remove_footers"):
        markdown = re.sub(r'^Page \d+ of \d+.*$', '', markdown, flags=re.MULTILINE)
        markdown = re.sub(r'^CONFIDENTIAL.*$', '', markdown, flags=re.MULTILINE)
        markdown = re.sub(r'^\d+\s*$', '', markdown, flags=re.MULTILINE)

    if rules.get("standardize_dates"):
        markdown = re.sub(
            r'\b(\d{1,2})[/\-](\d{1,2})[/\-](\d{2,4})\b',
            lambda m: f"{m.group(3).zfill(4)}-{m.group(1).zfill(2)}-{m.group(2).zfill(2)}",
            markdown
        )

    return markdown


def insert_chunks(markdown: str, doc_type: str, strategy: str) -> tuple[str, int]:
    """Insert RAG chunk boundary markers into the markdown."""
    lines = markdown.split("\n")
    output = []
    chunk_id = 0
    in_chunk = False
    token_est = 0

    def open_chunk():
        nonlocal chunk_id, in_chunk
        chunk_id += 1
        cid = f"{doc_type.replace('_','-')}-chunk-{chunk_id:03d}"
        return f"\n<!-- CHUNK_START id:{cid} strategy:{strategy} tokens:~{max(20, token_est)} -->\n"

    def close_chunk():
        nonlocal in_chunk
        in_chunk = False
        return "\n<!-- CHUNK_END -->\n"

    output.append(open_chunk())
    in_chunk = True

    for line in lines:
        token_est += max(1, len(line.split()) // 1)

        # Split on H2 headings
        if line.startswith("## ") and in_chunk and token_est > 30:
            output.append(close_chunk())
            output.append(open_chunk())
            in_chunk = True
            token_est = 0

        output.append(line)

    if in_chunk:
        output.append(close_chunk())

    return "\n".join(output), chunk_id


def build_metadata_yaml(job_data: dict) -> str:
    ctx = job_data.get("isa95_context", {})
    codes = job_data.get("apriso_codes", [])
    tags = [c["code"] for c in codes[:10]]

    lines = [
        f"document_type: {job_data.get('detected_doc_type_label', 'Unknown')}",
        f"apriso_module: {job_data.get('detected_apriso_module', '')}",
        f"extraction_engine: {job_data.get('extraction_engine', 'docling')}",
        f"ocr_engine: {job_data.get('ocr_engine', 'paddleocr')}",
        f"chunk_strategy: {job_data.get('chunk_strategy', 'section-boundary')}",
        f"chunks: {job_data.get('chunk_count', 0)}",
        f"tokens_est: {job_data.get('token_estimate', 0)}",
        f"page_count: {job_data.get('page_count', 0)}",
        f"word_count: {job_data.get('word_count', 0)}",
        "isa95:",
        f"  enterprise: {ctx.get('enterprise', 'Trane Technologies')}",
        f"  segment: {ctx.get('segment', '')}",
        f"  site: {ctx.get('site', '')}",
        f"  area: {ctx.get('area', '')}",
        f"  work_center: {ctx.get('work_center', '')}",
        f"  apriso_module_node: {ctx.get('apriso_module_node', '')}",
        "apriso_codes_extracted:",
    ]
    for tag in tags:
        lines.append(f"  - {tag}")

    return "\n".join(lines)


def build_eva_config(job_data: dict) -> dict:
    ctx = job_data.get("isa95_context", {})
    module = job_data.get("detected_apriso_module", "").lower().replace(" ", "_").replace("/", "_")
    site_code = ctx.get("site", "").replace(" ", "-").upper()[:8]
    area_code = ctx.get("area", "").replace(" ", "-").upper()[:8]
    collection = f"trane_apriso_{module}" if module else "trane_apriso_mes"
    path_parts = [
        ctx.get("enterprise", "TT")[:3].upper(),
        ctx.get("segment", "")[:8].upper().replace(" ", "-"),
        site_code,
        area_code,
    ]
    isa95_path = "/".join(p for p in path_parts if p)

    return {
        "collection": collection,
        "apriso_module": job_data.get("detected_apriso_module", ""),
        "chunk_strategy": job_data.get("chunk_strategy", "section-boundary"),
        "isa95_path": isa95_path,
        "embedding_hint": "BGE-M3",
        "metadata_schema": "apriso_mes_v1",
    }


def process_document(file_path: str, file_ext: str, job_config: dict, progress_cb=None) -> dict:
    """
    Main processing pipeline.
    progress_cb: callable(step_name: str, pct: float)
    """
    def progress(step, pct):
        if progress_cb:
            progress_cb(step, pct)

    progress("Extracting document content", 10)

    # Step 1: Extract
    try:
        if DOCLING_AVAILABLE and file_ext.lower() in (".pdf", ".docx", ".pptx", ".xlsx", ".html"):
            raw = extract_with_docling(file_path, file_ext)
            engine_used = "docling"
        else:
            raw = extract_fallback(file_path, file_ext)
            engine_used = "fallback"
    except Exception as e:
        logger.error(f"Primary extraction failed: {e}")
        raw = extract_fallback(file_path, file_ext)
        engine_used = "fallback"

    progress("Detecting document type", 30)

    # Step 2: Detect document type
    doc_type_key, doc_type_label, apriso_module, conf = detect_document_type(raw["markdown"])
    apriso_codes = extract_apriso_codes(raw["markdown"])
    chunk_strategy = get_chunk_strategy(doc_type_key)

    progress("Applying transformation rules", 50)

    # Step 3: Apply text rules
    rules = job_config.get("rules", {})
    md = apply_text_rules(raw["markdown"], rules)

    progress("Generating RAG chunk boundaries", 70)

    # Step 4: Insert chunks
    if rules.get("insert_chunks", True):
        md, chunk_count = insert_chunks(md, doc_type_key, chunk_strategy)
    else:
        chunk_count = 1

    token_estimate = len(md.split()) * 2  # rough approximation

    progress("Building metadata and EVA config", 85)

    # Step 5: Build metadata
    job_data = {
        **raw,
        "detected_doc_type": doc_type_key,
        "detected_doc_type_label": doc_type_label,
        "detected_apriso_module": apriso_module,
        "ocr_confidence": conf,
        "extraction_engine": engine_used,
        "ocr_engine": job_config.get("ocr_engine", "paddleocr"),
        "chunk_strategy": chunk_strategy,
        "chunk_count": chunk_count,
        "token_estimate": token_estimate,
        "isa95_context": job_config.get("isa95_context", {}),
        "apriso_codes": apriso_codes,
    }

    metadata_yaml = build_metadata_yaml(job_data)
    eva_config = build_eva_config(job_data)

    progress("Complete", 100)

    return {
        "markdown": md,
        "metadata_yaml": metadata_yaml,
        "eva_config": eva_config,
        "detected_doc_type": doc_type_key,
        "detected_doc_type_label": doc_type_label,
        "detected_apriso_module": apriso_module,
        "ocr_confidence": round(conf * 100, 1),
        "page_count": raw["page_count"],
        "word_count": raw["word_count"],
        "table_count": raw["table_count"],
        "image_count": raw["image_count"],
        "chunk_count": chunk_count,
        "token_estimate": token_estimate,
        "extraction_engine": engine_used,
        "apriso_codes": apriso_codes,
    }
