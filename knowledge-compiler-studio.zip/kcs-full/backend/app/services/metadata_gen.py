"""
Metadata generator: auto-tag documents with Apriso + ISA-95 metadata.
Heuristic-based, no LLM.
"""
import re
from typing import Dict, Any

APRISO_CODE_PATTERNS = [
    (r"NCR-[A-Z]{2}-\d{4}-\d{4}", "ncr_numbers"),
    (r"CAPA-\d{4}-\d{4}", "capa_numbers"),
    (r"DEF-[A-Z]+-\d{3,}", "defect_codes"),
    (r"EQ-[A-Z]+-[A-Z]+-\d{3,}", "equipment_ids"),
    (r"PO-\d{4}-[A-Z]+-\d{4,}", "production_orders"),
    (r"WO-[A-Z]+-\d{4,}", "work_orders"),
    (r"IP-[A-Z]+-[A-Z]+-\d{2,}", "inspection_plans"),
    (r"DISP-[A-Z]+-\d{3,}", "dispositions"),
    (r"LINE-[A-Z]+-[A-Z]+-[A-Z0-9]+", "production_lines"),
    (r"WC-[A-Z-]+\d*", "work_centers"),
]

SEVERITY_MAP = {
    "critical": "critical", "major": "major", "minor": "minor",
    "high": "high", "medium": "medium", "low": "low",
}

def generate_metadata(
    text: str,
    filename: str,
    doc_type: str,
    apriso_module: str,
    page_count: int,
    word_count: int,
    chunk_count: int,
    ocr_confidence: float,
) -> Dict[str, Any]:
    codes: Dict[str, list] = {k: [] for _, k in APRISO_CODE_PATTERNS}

    for pattern, key in APRISO_CODE_PATTERNS:
        matches = list(set(re.findall(pattern, text, re.IGNORECASE)))
        codes[key] = matches[:10]  # cap at 10

    # Severity
    severity = None
    for word, level in SEVERITY_MAP.items():
        if re.search(r"\b" + word + r"\b", text, re.IGNORECASE):
            severity = level
            break

    # Keywords — top domain terms
    stop = {"the","a","an","and","or","of","in","to","for","is","are","was","were",
            "be","been","being","have","has","had","do","does","did","at","by","from",
            "with","this","that","it","its","on","as","will","would","can","could",
            "not","but","if","he","she","they","we","you","i","page","document"}
    words = re.findall(r"\b[a-zA-Z]{4,}\b", text.lower())
    freq: Dict[str, int] = {}
    for w in words:
        if w not in stop:
            freq[w] = freq.get(w, 0) + 1
    keywords = sorted(freq, key=freq.get, reverse=True)[:20]

    return {
        "filename": filename,
        "doc_type": doc_type,
        "apriso_module": apriso_module,
        "page_count": page_count,
        "word_count": word_count,
        "chunk_count": chunk_count,
        "ocr_confidence": round(ocr_confidence, 2),
        "severity": severity,
        "extracted_codes": codes,
        "keywords": keywords,
        "chunk_strategy": _get_chunk_strategy(doc_type),
        "eva_config": _build_eva_config(apriso_module, doc_type),
    }

def _get_chunk_strategy(doc_type: str) -> str:
    mapping = {
        "NCR Report": "mes-ncr-triplet",
        "CAPA Document": "mes-ncr-triplet",
        "RCA Report": "mes-ncr-triplet",
        "KB Article": "mes-kb-triplet",
        "Support Ticket": "mes-kb-triplet",
        "Work Instruction": "procedure-step",
        "Maintenance Plan": "procedure-step",
    }
    return mapping.get(doc_type, "heading-boundary")

def _build_eva_config(apriso_module: str, doc_type: str) -> dict:
    module_collection_map = {
        "quality":     "trane_apriso_quality",
        "issue_mgmt":  "trane_apriso_quality_ncr",
        "maintenance": "trane_apriso_maintenance",
        "oee":         "trane_apriso_oee",
        "production":  "trane_apriso_production",
        "knowledge_base": "trane_apriso_kb",
        "configuration":  "trane_apriso_config",
    }
    return {
        "collection": module_collection_map.get(apriso_module, "trane_apriso_general"),
        "apriso_module": apriso_module,
        "chunk_strategy": _get_chunk_strategy(doc_type),
        "embedding_hint": "BGE-M3",
        "metadata_schema": "apriso_mes_v1",
    }

def metadata_to_yaml(meta: dict) -> str:
    import yaml
    return yaml.dump(meta, default_flow_style=False, allow_unicode=True)
