import io
from minio import Minio
from minio.error import S3Error
from app.config import get_settings

settings = get_settings()

def get_minio_client() -> Minio:
    return Minio(
        settings.minio_endpoint,
        access_key=settings.minio_access_key,
        secret_key=settings.minio_secret_key,
        secure=settings.minio_secure,
    )

def upload_file(bucket: str, key: str, data: bytes, content_type: str = "application/octet-stream") -> str:
    client = get_minio_client()
    client.put_object(bucket, key, io.BytesIO(data), length=len(data), content_type=content_type)
    return key

def download_file(bucket: str, key: str) -> bytes:
    client = get_minio_client()
    response = client.get_object(bucket, key)
    return response.read()

def get_presigned_url(bucket: str, key: str, expires_seconds: int = 3600) -> str:
    from datetime import timedelta
    client = get_minio_client()
    return client.presigned_get_object(bucket, key, expires=timedelta(seconds=expires_seconds))

def object_exists(bucket: str, key: str) -> bool:
    client = get_minio_client()
    try:
        client.stat_object(bucket, key)
        return True
    except S3Error:
        return False
