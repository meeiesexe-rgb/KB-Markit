import os, logging, tempfile
from celery import Celery
from datetime import datetime

logger = logging.getLogger(__name__)

REDIS_URL = os.environ.get("REDIS_URL", "redis://localhost:6379/0")

celery_app = Celery(
    "kcs_worker",
    broker=REDIS_URL,
    backend=REDIS_URL,
    include=["app.worker.tasks"],
)

celery_app.conf.update(
    task_serializer="json",
    accept_content=["json"],
    result_serializer="json",
    timezone="UTC",
    enable_utc=True,
    task_routes={"app.worker.tasks.*": {"queue": "kcs_jobs"}},
    worker_prefetch_multiplier=1,
    task_acks_late=True,
)
