import os, logging, json, tempfile, zipfile, io
from datetime import datetime
from pathlib import Path
from celery import current_task
from app.worker.celery_app import celery_app
from app.services.extractor import process_document
from app.services.storage import download_file, upload_file
from app.config import get_settings

logger = logging.getLogger(__name__)
settings = get_settings()


def update_job_db(job_id: str, updates: dict):
    """Synchronous DB update for Celery worker (uses psycopg2 directly)."""
    import psycopg2
    db_url = settings.database_url.replace("postgresql+asyncpg://", "postgresql://")
    try:
        conn = psycopg2.connect(db_url)
        cur = conn.cursor()
        set_clauses = ", ".join(f"{k} = %s" for k in updates.keys())
        values = list(updates.values()) + [job_id]
        cur.execute(f"UPDATE processing_jobs SET {set_clauses} WHERE id = %s", values)
        conn.commit()
        cur.close()
        conn.close()
    except Exception as e:
        logger.error(f"DB update failed for job {job_id}: {e}")


@celery_app.task(bind=True, name="app.worker.tasks.process_job", max_retries=2)
def process_job(self, job_id: str, minio_doc_key: str, file_ext: str, job_config: dict):
    """Main Celery task: download → extract → transform → package → upload."""
    logger.info(f"Starting job {job_id}")

    def progress(step: str, pct: float):
        update_job_db(job_id, {
            "status": "processing",
            "progress": pct,
            "current_step": step,
        })
        self.update_state(state="PROGRESS", meta={"step": step, "pct": pct})

    try:
        progress("Downloading document from storage", 5)

        # Download from MinIO
        file_bytes = download_file(settings.minio_bucket_docs, minio_doc_key)

        # Write to temp file
        with tempfile.NamedTemporaryFile(suffix=file_ext, delete=False) as tmp:
            tmp.write(file_bytes)
            tmp_path = tmp.name

        # Process
        result = process_document(
            file_path=tmp_path,
            file_ext=file_ext,
            job_config=job_config,
            progress_cb=progress,
        )

        # Clean up temp file
        try:
            os.unlink(tmp_path)
        except Exception:
            pass

        progress("Building export package", 90)

        # Build ZIP package in memory
        zip_buffer = io.BytesIO()
        with zipfile.ZipFile(zip_buffer, "w", zipfile.ZIP_DEFLATED) as zf:
            zf.writestr("document.md", result["markdown"])
            zf.writestr("metadata.yaml", result["metadata_yaml"])
            zf.writestr("eva-config.json", json.dumps(result["eva_config"], indent=2))
            audit = {
                "job_id": job_id,
                "processed_at": datetime.utcnow().isoformat(),
                "engine": result["extraction_engine"],
                "doc_type": result["detected_doc_type_label"],
                "apriso_module": result["detected_apriso_module"],
                "chunks": result["chunk_count"],
                "tokens_est": result["token_estimate"],
                "rules_applied": job_config.get("rules", {}),
            }
            zf.writestr("audit.json", json.dumps(audit, indent=2))

        zip_bytes = zip_buffer.getvalue()
        package_key = f"packages/{job_id}/knowledge-package.zip"
        upload_file(settings.minio_bucket_packages, package_key, zip_bytes, "application/zip")

        progress("Saving results", 97)

        update_job_db(job_id, {
            "status": "complete",
            "progress": 100.0,
            "current_step": "Complete",
            "detected_doc_type": result["detected_doc_type_label"],
            "detected_apriso_module": result["detected_apriso_module"],
            "page_count": result["page_count"],
            "word_count": result["word_count"],
            "table_count": result["table_count"],
            "image_count": result["image_count"],
            "ocr_confidence": result["ocr_confidence"],
            "markdown_content": result["markdown"][:50000],  # DB column limit
            "metadata_yaml": result["metadata_yaml"],
            "eva_config": json.dumps(result["eva_config"]),
            "chunk_count": result["chunk_count"],
            "token_estimate": result["token_estimate"],
            "minio_package_key": package_key,
            "completed_at": datetime.utcnow().isoformat(),
        })

        logger.info(f"Job {job_id} complete — {result['chunk_count']} chunks")
        return {"status": "complete", "job_id": job_id}

    except Exception as exc:
        logger.error(f"Job {job_id} failed: {exc}", exc_info=True)
        update_job_db(job_id, {
            "status": "failed",
            "current_step": "Failed",
            "error_message": str(exc)[:512],
        })
        raise self.retry(exc=exc, countdown=5)
