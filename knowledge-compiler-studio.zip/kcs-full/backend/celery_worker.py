# ══════════════════════════════════════════════════
# celery_worker.py
# ══════════════════════════════════════════════════
from celery import Celery
import os

REDIS_URL = os.getenv("REDIS_URL", "redis://localhost:6379/0")

celery_app = Celery("kcs", broker=REDIS_URL, backend=REDIS_URL)
celery_app.conf.task_serializer = "json"
celery_app.conf.result_serializer = "json"

@celery_app.task(bind=True, name="process_document_task")
def process_document_task(self, job_id: str, file_path: str, config: dict):
    """Celery task — wraps the same pipeline logic."""
    import asyncio
    from main import JOBS, run_pipeline_inline
    import os

    suffix = os.path.splitext(file_path)[-1].lower()
    with open(file_path, "rb") as f:
        content = f.read()

    def update_state(progress, stage):
        JOBS[job_id]["progress"] = progress
        JOBS[job_id]["stage"] = stage
        self.update_state(state="PROGRESS", meta={"progress": progress, "stage": stage})

    asyncio.run(run_pipeline_inline(job_id, file_path, suffix, content))
