"""
Knowledge Compiler Studio — FastAPI Backend
Apriso MES Document Intelligence Platform · Trane Technologies
"""
import os, uuid, json, asyncio
from datetime import datetime
from typing import Optional
from pathlib import Path

from fastapi import FastAPI, UploadFile, File, HTTPException, BackgroundTasks
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse, FileResponse, StreamingResponse
from pydantic import BaseModel

app = FastAPI(title="Knowledge Compiler Studio", version="1.0.0")
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_credentials=True,
                   allow_methods=["*"], allow_headers=["*"])

JOBS: dict = {}
OUTPUTS: dict = {}
UPLOAD_DIR = Path("/tmp/kcs_uploads")
OUTPUT_DIR = Path("/tmp/kcs_outputs")
UPLOAD_DIR.mkdir(exist_ok=True)
OUTPUT_DIR.mkdir(exist_ok=True)

SUPPORTED_EXT = {".pdf",".docx",".xlsx",".pptx",".txt",".html",".csv",".png",".jpg",".jpeg",".tiff"}

APRISO_PATTERNS = {
    "NCR Report":       ["non-conformance","ncr","defect code","disposition","def-","ncr-"],
    "CAPA Document":    ["corrective action","capa","preventive","root cause","8d","5-why"],
    "Work Instruction": ["work instruction","operation","procedure","sop","step 1","step 2"],
    "Maintenance Plan": ["maintenance","pm schedule","calibration","cmms","work order","preventive"],
    "OEE Report":       ["oee","availability","performance","downtime","quality loss","utilization"],
    "KB Article":       ["resolution","symptoms","workaround","affected version","knowledge base","kb-"],
    "Support Ticket":   ["ticket","priority","status","customer","reported by","issue id"],
    "Production Order": ["production order","work order","routing","bom","dispatch","qty"],
    "Apriso Config":    ["flexnet","process","activity","container","apriso","operation definition"],
}

MODULE_MAP = {
    "NCR Report":"Issue Management","CAPA Document":"Quality Management",
    "Work Instruction":"Production","Maintenance Plan":"CMMS / Maintenance",
    "OEE Report":"OEE / Performance","KB Article":"Support KB",
    "Support Ticket":"Support KB","Production Order":"Production",
    "Apriso Config":"Production",
}

CHUNK_STRATEGIES = {
    "NCR Report":"mes-ncr-triplet","CAPA Document":"mes-ncr-triplet",
    "KB Article":"mes-kb-triplet","Support Ticket":"mes-kb-triplet",
    "OEE Report":"mes-oee-boundary","Maintenance Plan":"mes-equipment-boundary",
}

class ProcessRequest(BaseModel):
    job_id: str
    rules: dict = {}
    isa95_context: dict = {}
    template: str = "wi"
    extraction_engine: str = "docling"
    ocr_engine: str = "paddleocr"

def detect_doc_type(filename, sample=""):
    combined = filename.lower() + " " + sample.lower()
    scores = {k:sum(1 for p in v if p in combined) for k,v in APRISO_PATTERNS.items()}
    scores = {k:v for k,v in scores.items() if v>0}
    if scores:
        best = max(scores, key=scores.get)
        conf = min(0.96, 0.55 + scores[best]*0.12)
        return best, MODULE_MAP.get(best,"Production"), conf
    return "Work Instruction", "Production", 0.55

def extract_tags(text):
    import re
    patterns = [
        (r'\bNCR-[A-Z]+-\d{4}-\d+\b','issue','ti-alert-triangle'),
        (r'\bDEF-[A-Z]+-\d{3}\b','qual','ti-circle-check'),
        (r'\bPO-\d{4}-[A-Z]+-\d+\b','proc','ti-file-invoice'),
        (r'\bWO-[A-Z]+-\d+\b','maint','ti-tool'),
        (r'\bEQ-[A-Z]+-[A-Z]+-\d+\b','equip','ti-cpu'),
        (r'\bIP-[A-Z]+-[A-Z]+-\d+\b','qual','ti-clipboard-check'),
        (r'\bCAPA-\d+\b','qual','ti-rotate-clockwise-2'),
    ]
    found,seen = [],set()
    for pat,typ,ico in patterns:
        for m in re.finditer(pat,text,re.IGNORECASE):
            v=m.group().upper()
            if v not in seen:
                seen.add(v)
                found.append({"label":v,"type":typ,"icon":ico})
    return found[:20]

def build_isa95_path(isa95):
    parts=[v[:10].upper().replace(" ","-") for k,v in isa95.items() if v and k in
           ["enterprise","segment","site","area","work_center"]]
    return "/".join(parts) or "TT/UNKNOWN"

def build_markdown(filename, doc_type, module, conf, tags, isa95, content):
    base = Path(filename).stem
    path = build_isa95_path(isa95)
    strat = CHUNK_STRATEGIES.get(doc_type,"procedure-aware")
    tag_str = " · ".join(t["label"] for t in tags[:6]) or "none detected"

    header_chunk = f"""<!-- CHUNK_START id:{base}-header strategy:{strat} tokens:~72 -->

## Document identification

| Field | Value |
|---|---|
| Document | `{filename}` |
| Type | {doc_type} |
| Apriso module | {module} |
| ISA-95 path | `{path}` |
| Confidence | {int(conf*100)}% |
| Apriso tags | {tag_str} |

<!-- CHUNK_END -->"""

    content_clean = content[:1200].strip() if len(content)>100 else "*Upload a real document to see extracted content.*"
    content_chunk = f"""<!-- CHUNK_START id:{base}-content-1 strategy:{strat} tokens:~148 -->

## Extracted content

{content_clean}

<!-- CHUNK_END -->"""

    isa_rows = "\n".join(f"| {k.replace('_',' ').title()} | {v} |"
                         for k,v in isa95.items() if v)
    meta_chunk = ""
    if isa_rows:
        meta_chunk = f"""<!-- CHUNK_START id:{base}-metadata strategy:{strat} tokens:~56 -->

## ISA-95 context

| Level | Value |
|---|---|
{isa_rows}

<!-- CHUNK_END -->"""

    tag_chunk = ""
    if tags:
        tag_rows = "\n".join(f"| `{t['label']}` | {t['type']} |" for t in tags)
        tag_chunk = f"""<!-- CHUNK_START id:{base}-tags strategy:{strat} tokens:~44 -->

## Apriso taxonomy tags

| Code | Category |
|---|---|
{tag_rows}

<!-- CHUNK_END -->"""

    parts = [p for p in [header_chunk, content_chunk, meta_chunk, tag_chunk] if p]
    md = (f"# {base.replace('-',' ').replace('_',' ')}\n\n"
          f"> **Document type:** {doc_type}  \n"
          f"> **Apriso module:** {module}  \n"
          f"> **ISA-95:** `{path}`\n\n"
          + "\n\n".join(parts))
    sections = [
        {"id":f"{base}-header",   "label":"Document identification","tokens":72},
        {"id":f"{base}-content-1","label":"Extracted content",       "tokens":148},
        {"id":f"{base}-metadata", "label":"ISA-95 context",          "tokens":56},
        {"id":f"{base}-tags",     "label":"Apriso tags",             "tokens":44},
    ]
    return {"markdown":md,"chunk_count":len(parts),"sections":sections}

async def run_pipeline(job_id, file_path, filename, rules, isa95, template, engine, ocr):
    job = JOBS[job_id]
    steps_def = [
        ("text_extraction",  "Text extraction",        2.0,100),
        ("table_detection",  "Table detection",        1.5,100),
        ("table_parsing",    "Table parsing",          2.0, 85),
        ("apriso_codes",     "Apriso code extraction", 1.0, 95),
        ("chunk_generation", "Chunk generation",       1.5, 90),
        ("metadata_tagging", "Metadata tagging",       1.0,100),
        ("eva_config",       "EVA config generation",  0.5,100),
    ]
    try:
        sample = Path(file_path).read_text(errors="ignore")[:2000]
    except:
        sample = filename

    doc_type, module, conf = detect_doc_type(filename, sample)
    tags = extract_tags(sample)
    done_steps = []

    for i,(key,label,delay,step_conf) in enumerate(steps_def):
        await asyncio.sleep(delay)
        done_steps.append({"key":key,"label":label,"pct":step_conf,"done":True})
        job.update({"status":"processing","progress":int((i+1)/len(steps_def)*100),
                    "steps":done_steps[:],"current_step":label})

    chunks = build_markdown(filename, doc_type, module, conf, tags, isa95, sample)
    now = datetime.utcnow().isoformat()+"Z"
    metadata = {
        "document_type":doc_type,"apriso_module":module,
        "chunk_strategy":CHUNK_STRATEGIES.get(doc_type,"procedure-aware"),
        "filename":filename,"isa95":isa95,
        "ocr_confidence":round(conf,2),"total_chunks":chunks["chunk_count"],
        "estimated_tokens":chunks["chunk_count"]*150,"tags":tags,
        "processed_at":now,"engine":engine,"ocr_engine":ocr,
    }
    eva_config = {
        "collection":f"trane_apriso_{module.lower().replace(' ','_').replace('/','_')}",
        "apriso_module":module.lower().replace(" ","_"),
        "chunk_strategy":CHUNK_STRATEGIES.get(doc_type,"procedure-aware"),
        "isa95_path":build_isa95_path(isa95),
        "embedding_hint":"BGE-M3","metadata_schema":"apriso_mes_v1",
    }
    result = {"doc_type":doc_type,"apriso_module":module,"confidence":conf,
              "markdown":chunks["markdown"],"chunk_count":chunks["chunk_count"],
              "metadata":metadata,"eva_config":eva_config,"tags":tags,
              "sections":chunks["sections"]}
    OUTPUTS[job_id] = result
    (OUTPUT_DIR/f"{job_id}.json").write_text(json.dumps(result,indent=2))
    job.update({"status":"done","progress":100,"result":result})

@app.get("/health")
async def health():
    return {"status":"ok","service":"knowledge-compiler-studio","version":"1.0.0"}

@app.post("/api/upload")
async def upload_document(file: UploadFile = File(...)):
    ext = Path(file.filename).suffix.lower()
    if ext not in SUPPORTED_EXT:
        raise HTTPException(400, f"Unsupported file type: {ext}")
    job_id = str(uuid.uuid4())[:8]
    dest = UPLOAD_DIR / f"{job_id}_{Path(file.filename).name}"
    content = await file.read()
    dest.write_bytes(content)
    sample = content.decode("utf-8",errors="ignore")[:2000]
    doc_type, module, conf = detect_doc_type(file.filename, sample)
    tags = extract_tags(sample)
    JOBS[job_id] = {"job_id":job_id,"status":"uploaded","progress":0,"steps":[],
                    "filename":file.filename,"file_path":str(dest),"file_size":len(content),
                    "doc_type":doc_type,"module":module,"confidence":conf,"tags":tags,
                    "created_at":datetime.utcnow().isoformat()+"Z","current_step":None,"result":None}
    return {"job_id":job_id,"filename":file.filename,"file_size":len(content),
            "doc_type":doc_type,"apriso_module":module,"confidence":conf,"tags":tags,"status":"uploaded"}

@app.post("/api/process")
async def process_document(req: ProcessRequest, background_tasks: BackgroundTasks):
    if req.job_id not in JOBS:
        raise HTTPException(404,"Job not found")
    job = JOBS[req.job_id]
    if job["status"] == "processing":
        raise HTTPException(409,"Already processing")
    if not Path(job["file_path"]).exists():
        raise HTTPException(404,"Upload file missing")
    job.update({"status":"processing","progress":0,"steps":[]})
    background_tasks.add_task(run_pipeline, req.job_id, Path(job["file_path"]),
                               job["filename"], req.rules, req.isa95_context,
                               req.template, req.extraction_engine, req.ocr_engine)
    return {"job_id":req.job_id,"status":"processing"}

@app.get("/api/jobs/{job_id}")
async def get_job(job_id: str):
    if job_id not in JOBS: raise HTTPException(404,"Not found")
    return JOBS[job_id]

@app.get("/api/jobs/{job_id}/stream")
async def stream_job(job_id: str):
    if job_id not in JOBS: raise HTTPException(404,"Not found")
    async def gen():
        while True:
            job = JOBS.get(job_id,{})
            yield f"data: {json.dumps({'status':job.get('status'),'progress':job.get('progress',0),'step':job.get('current_step'),'steps':job.get('steps',[])})}\n\n"
            if job.get("status") in ("done","error"): break
            await asyncio.sleep(0.4)
    return StreamingResponse(gen(), media_type="text/event-stream")

@app.get("/api/jobs/{job_id}/result")
async def get_result(job_id: str):
    if job_id not in OUTPUTS: raise HTTPException(404,"Result not ready")
    return OUTPUTS[job_id]

@app.get("/api/jobs/{job_id}/download")
async def download_package(job_id: str):
    if job_id not in OUTPUTS: raise HTTPException(404,"Result not ready")
    r = OUTPUTS[job_id]
    content = "\n\n".join([
        "=== Knowledge Compiler Studio — Export Package ===",
        f"=== Generated: {datetime.utcnow().isoformat()}Z ===\n",
        "=== document.md ===", r.get("markdown",""),
        "=== metadata.yaml ===",
        "\n".join(f"{k}: {json.dumps(v) if isinstance(v,(dict,list)) else v}"
                  for k,v in r.get("metadata",{}).items()),
        "=== eva-config.json ===", json.dumps(r.get("eva_config",{}),indent=2),
        "=== audit.json ===",
        json.dumps({"job_id":job_id,"processed_at":r["metadata"].get("processed_at"),
                    "engine":r["metadata"].get("engine"),"chunks":r.get("chunk_count"),
                    "tags_found":len(r.get("tags",[]))},indent=2),
    ])
    fname = f"kcs-package-{job_id}.txt"
    out = OUTPUT_DIR/fname
    out.write_text(content)
    return FileResponse(str(out), filename=fname, media_type="text/plain")

@app.get("/api/jobs")
async def list_jobs():
    return sorted(JOBS.values(), key=lambda j:j.get("created_at",""), reverse=True)[:50]

@app.delete("/api/jobs/{job_id}")
async def delete_job(job_id: str):
    if job_id not in JOBS: raise HTTPException(404,"Not found")
    job = JOBS.pop(job_id)
    OUTPUTS.pop(job_id,None)
    try: Path(job["file_path"]).unlink(missing_ok=True)
    except: pass
    return {"deleted":job_id}
